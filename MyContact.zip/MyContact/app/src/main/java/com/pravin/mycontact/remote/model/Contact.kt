package com.pravin.mycontact.remote.model

data class Contact(
    val info: Info,
    val results: List<Result>
)