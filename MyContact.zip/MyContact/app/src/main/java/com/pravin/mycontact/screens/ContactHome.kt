package com.pravin.mycontact.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavController
import com.pravin.mycontact.MainActivity
import com.pravin.mycontact.ui.theme.MyContactTheme
import com.pravin.mycontact.viewmodel.ContactViewModel
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

@SuppressLint("SuspiciousIndentation")
@Composable
fun ContactHome(
    modifier: Modifier = Modifier,
    viewModel: ContactViewModel,
    navController: NavController
    ) {
    val contact = viewModel.contacts.observeAsState()
        contact.value?.let { check ->
            ContactList(
                modifier = modifier,
                contact = check,
                onClick = { viewModel.getContactDetail(it) },
                onNavigate = {
                    val imageUrl = URLEncoder.encode(it.picture.large, StandardCharsets.UTF_8.toString())
                    navController.navigate("${MainActivity.NavigationItem.ContactDetail}/${it.name.title}/${it?.name?.first}/${it?.name?.last}/${it?.email}/${it?.cell}/${it?.phone}/${imageUrl}")
                }
            )
        } ?: run {
            Text(text = "Loading contacts...", modifier = modifier)
        }
}

@Preview
@Composable
private fun ContactHomePreview() {
    MyContactTheme {
//        ContactHome(
//            viewModel = ContactViewModel()
//        )
    }
}