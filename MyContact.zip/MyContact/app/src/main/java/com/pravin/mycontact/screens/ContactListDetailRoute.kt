package com.pravin.mycontact.screens

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.pravin.mycontact.remote.model.Result

@Composable
fun ContactListDetailRoute(
    modifier: Modifier,
    isExpandWindowSize: Boolean,
    selectedContact: Result
    ) {

}