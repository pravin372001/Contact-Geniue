package com.pravin.mycontact.remote.model

data class Name(
    val first: String,
    val last: String,
    val title: String
)