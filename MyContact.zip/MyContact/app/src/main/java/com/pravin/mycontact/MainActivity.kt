package com.pravin.mycontact

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.pravin.mycontact.screens.ContactDetail
import com.pravin.mycontact.screens.ContactHome
import com.pravin.mycontact.screens.ContactList
import com.pravin.mycontact.ui.theme.MyContactTheme
import com.pravin.mycontact.viewmodel.ContactViewModel

class MainActivity : ComponentActivity() {

    private lateinit var viewModel: ContactViewModel

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel = ViewModelProvider(this, ContactViewModel.ContactViewModelFactory(application))[ContactViewModel::class.java]
        setContent {
            MyContactTheme {
                val navController = rememberNavController()
                var showBackButton by rememberSaveable {
                    mutableStateOf(false)
                }
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                showBackButton = when(navBackStackEntry?.destination?.route){
                    NavigationItem.ContactList.name -> false
                    else -> true
                }
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text(text = "Contact Geniue") },
                            navigationIcon = { if(showBackButton) { IconButton(onClick = { navController.navigateUp() }) {
                                Icon(imageVector = Icons.Filled.ArrowBack, contentDescription = null)
                            } }
                            },
                            colors = TopAppBarColors(
                                MaterialTheme.colorScheme.primaryContainer,
                                MaterialTheme.colorScheme.secondaryContainer,
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.primary,
                                MaterialTheme.colorScheme.tertiary
                            )
                        )
                    }
                ) { paddingValues ->
                    NavHost(navController = navController, startDestination = NavigationItem.ContactList.name) {
                        composable(NavigationItem.ContactList.name){
                            ContactHome(
                                modifier = Modifier.padding(paddingValues),
                                viewModel = viewModel,
                                navController = navController
                            )
                        }
                        composable(
                            "${ NavigationItem.ContactDetail.name}/{title}/{name}/{last}/{email}/{cell}/{phone}/{imageurl}",
                            arguments = listOf(
                                navArgument("title"){
                                    type = NavType.StringType
                                },
                                navArgument("name"){
                                    type = NavType.StringType
                                },
                                navArgument("last"){
                                    type = NavType.StringType
                                },navArgument("email"){
                                    type = NavType.StringType
                                },navArgument("cell"){
                                    type = NavType.StringType
                                },navArgument("phone"){
                                    type = NavType.StringType
                                },navArgument("imageurl"){
                                    type = NavType.StringType
                                },
                            )
                        ){ backStackEntry ->
                            val title = backStackEntry.arguments?.getString("title") ?: ""
                            val name = backStackEntry.arguments?.getString("name")?: ""
                            val last = backStackEntry.arguments?.getString("last")?: ""
                            val email = backStackEntry.arguments?.getString("email")?: ""
                            val cell = backStackEntry.arguments?.getString("cell")?: ""
                            val phone = backStackEntry.arguments?.getString("phone")?: ""
                            val imageUrl = backStackEntry.arguments?.getString("imageurl")?: ""
                            ContactDetail(
                                modifier = Modifier,
                                title = title,
                                name = name,
                                lastName = last,
                                email = email,
                                cell = cell,
                                phone = phone,
                                imageUrl = imageUrl
                            )
                        }
                    }
                }

            }
        }
    }

    enum class NavigationItem{
        ContactList,
        ContactDetail
    }
}


