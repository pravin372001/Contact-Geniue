package com.pravin.mycontact.remote.model

data class Id(
    val name: String,
    val value: String
)