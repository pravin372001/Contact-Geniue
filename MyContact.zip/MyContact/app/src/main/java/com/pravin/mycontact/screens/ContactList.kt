package com.pravin.mycontact.screens

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.pravin.mycontact.remote.model.Contact
import com.pravin.mycontact.remote.model.Result
import com.pravin.mycontact.ui.theme.MyContactTheme

@Composable
fun ContactList(
    modifier: Modifier,
    contact: Contact,
    onClick: (String) -> Result?,
    onNavigate:(Result)-> Unit
) {
    ContactListContent(
        modifier = modifier,
        contact = contact,
        onNavigate = onNavigate
    )
}

@Composable
fun ContactListContent(
    modifier: Modifier,
    contact: Contact,
    onNavigate:(Result)-> Unit
) {
    LazyColumn(
        modifier = modifier.padding(8.dp)
            .fillMaxSize()
    ){
        items(contact.results) {
            ContactItem(
                contact = it,
                imageUrl = it.picture.medium,
                name = it.name.first + " " + it.name.last,
                onNavigate = onNavigate
            )
        }
    }
}

@Preview
@Composable
fun ContactListPreview() {
    MyContactTheme {
//        ContactListContent(
//
//        )
    }
}